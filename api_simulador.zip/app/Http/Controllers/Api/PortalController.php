<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\Email;
use Illuminate\Http\Request;
use App\Http\Controllers\Api\EmailController;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Firebase\JWT\JWT;




class PortalController extends Controller
{
    public $email;
    public function __construct(){
        $this->email = new EmailController();
    }

    function enviar(Request $request)
    {   
        if(env('API_TOKEN') == $request->token ){
            $aux=$this->set($request->email);
            return json_encode($aux);
        }else{
          return json_encode('Acesso Negado');  
        }
    }

    function teste() {
        
    } 
    
    function cripto($x) {
        
            $a = mt_rand(2, 8);
        
            $b = 'dpsfbasb';
            
        
            $c = 59;
        
            $d = '';
            $xStr = strval($x);
            $cStr = strval($c);
            $bIndex = 0;
            for ($i = 0; $i < 8; $i++) {
                if ($i >= 6) {
                    $d .= $cStr[$bIndex];
                    $d .= $b[$i];
                    $bIndex++;
                }else{
                    $d .= $xStr[$i];
                    $d .= $b[$i];
                }
            }
        
        
            $f ='';
            
                for ($i = 0; $i < strlen($d); $i++) {
                    $f.=$d[($i + $a)%16];
                }
            
            $resultado = md5($f) . $a;
            return $resultado;
                    
    }
    
    function gerarOTP() {
        // Defina o comprimento do código OTP
        $length = 6;

        // Gere um código aleatório de $length dígitos
        $otp = rand(pow(10, $length-1), pow(10, $length)-1);

        // Retorne o código gerado
        return $otp;
    }

    function set($email){
        $otpCode = $this->gerarOTP();
        
        $responses=$this->email->email_portal($email,$otpCode);

        $response = $this->cripto($otpCode);
        return $response;
    }
    
    function save_token($token){
        // Caminho para o arquivo .env
            $envFilePath = base_path('.env');
            
            // Ler o conteúdo do arquivo .env
            $envContentArray = file($envFilePath);

            // Alterar a variável NOME_DA_VARIAVEL
            foreach ($envContentArray as $key => $line) {
                if (strpos($line, 'AUTH_TOKEN=') !== false) {
                    $envContentArray[$key] = "AUTH_TOKEN=".$token."\n";
                    break;
                }
            }
            
            File::put($envFilePath, implode('', $envContentArray));
            
            return 1;
            
    }

    function login(Request $request) {
        try {
            if(env('API_TOKEN') == $request->token ){
                $aux=$this->gerarJWT($request->id_user,$request->email_user);
                return response()->json([
                    'msg' => 'Autenticação feita com sucesso',
                    'nome' => $request->nome_user,
                    'token' => $aux
                ],200);
                
            }else{
                return response()->json([
                    'error' => 'Acesso negado'
                ],402);
                            }
        } catch (\Throwable $th) {
            return response()->json([
                'error' => true,
                 'message' => $th->getMessage()   
            ],400);        }
    }

    function get_token(Request $request) {
        try {
            if(env('API_TOKEN') == $request->token ){
                return response()->json([
                    'token' => env('AUTH_TOKEN')
                ],200);
            }else{
                return response()->json([
                    'error' => 'Acesso negado'
                ],402);
                            }
        } catch (\Throwable $th) {
            return response()->json([
                'error' => true,
                 'message' => $th->getMessage()   
            ],400);        }
    }

    function new_token_api(Request $request) {
        try {
            if(env('API_TOKEN') == $request->token ){
                $aux= $this->save_token($request->new_token);
                return response()->json([
                    'msg' => 'Salvo com sucesso!'
                ],200);
            }else{
                return response()->json([
                    'error' => 'Acesso negado'
                ],402);
                            }
        } catch (\Throwable $th) {
            return response()->json([
                'error' => true,
                 'message' => $th->getMessage()   
            ],400);        }
    }

    function gerarJWT($id,$email) {

        try {
            $chaveSecreta = env('JWT_SECRET'); 
            
            $payload = [
                'id' => $id,
                'email' => $email,
                'exp' => time() + (24 * 60 * 60) 
            ];

            $token = JWT::encode($payload, $chaveSecreta, 'HS256');
            return $token;
        } catch (\Throwable $th) {
            //throw $th;
        }
        
    }

    function refreshToken($token) {

        try {
            $chaveSecreta = env('JWT_SECRET'); 
            
            $decoded = JWT::decode($token, $chaveSecreta, ['HS256']);
            $payload = (array) $decoded;

            // Verifica se o token ainda é válido
            if (isset($payload['exp']) && $payload['exp'] > time()) {
                // Token ainda é válido, então podemos gerar um novo token com uma nova expiração
                $novoToken = gerarTokenJWT($payload['id'], $payload['email'], $payload['nome'], 24 * 60);
                return $novoToken;
            }
        } catch (\Throwable $th) {
            //throw $th;
        }
        
    }
    
    /*$response= $this->save_token('SO PARA CONFIRMAR');
                return 'A API ESTA A FUNCIONAR';       
      
    */    
     
    
}
